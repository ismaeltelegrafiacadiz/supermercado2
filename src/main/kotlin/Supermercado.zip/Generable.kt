package EXAMEN_RC

interface Generable {
    // Función que genera el id de las Bebidas y lo devuelve a tipo cadena
    fun generarID(): String
}